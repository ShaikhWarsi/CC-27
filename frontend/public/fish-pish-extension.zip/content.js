let o=null,i=null,r=null;const u=400;document.addEventListener("mouseover",t=>{const n=t.target.closest("a");n&&n.href&&(o&&clearTimeout(o),o=setTimeout(()=>{f(n.href,n.getBoundingClientRect())},u))});document.addEventListener("mouseout",t=>{t.target.closest("a")&&(o&&clearTimeout(o),i&&!i.dataset.expanded&&setTimeout(()=>c(),5e3))});async function f(t,e){if(!(r===t&&i)){c(),r=t,g(e);try{const n=await chrome.runtime.sendMessage({type:"ANALYZE_URL",url:t});n.success?v(n.data):p(n.error)}catch{p("Connection failed")}}}function y(t){const e=document.createElement("div");return e.id="lg-popup",e.style.position="absolute",e.style.top=`${t.bottom+window.scrollY+5}px`,e.style.left=`${t.left+window.scrollX}px`,e.style.zIndex="999999",e.style.backgroundColor="white",e.style.borderRadius="8px",e.style.boxShadow="0 4px 12px rgba(0,0,0,0.15)",e.style.padding="12px",e.style.fontFamily="system-ui, -apple-system, sans-serif",e.style.minWidth="200px",e.style.transition="all 0.2s ease",e.style.border="1px solid #eee",document.body.appendChild(e),i=e,e}function g(t){const e=y(t);e.innerHTML=`
    <div style="display: flex; align-items: center; gap: 8px;">
      <div class="lg-spinner" style="width: 16px; height: 16px; border: 2px solid #f3f3f3; border-top: 2px solid #3498db; border-radius: 50%; animation: spin 1s linear infinite;"></div>
      <span style="font-size: 12px; color: #666;">Scanning link...</span>
    </div>
    <style>
      @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
  `}function v(t){if(!i)return;const{phishing_probability:e,summary:n,color:d}=t;let s="#2ecc71";d==="red"?s="#e74c3c":d==="yellow"&&(s="#f1c40f"),i.innerHTML=`
    <div style="display: flex; flex-direction: column; gap: 8px;">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <span style="font-weight: 600; font-size: 14px;">Fish Pish</span>
        <span style="font-size: 12px; font-weight: bold; color: ${s};">${e}% Risk</span>
      </div>
      <div style="height: 4px; background: #eee; border-radius: 2px; overflow: hidden;">
        <div style="height: 100%; width: ${e}%; background: ${s};"></div>
      </div>
      <p style="margin: 0; font-size: 12px; color: #444;">${n}</p>
      <button id="lg-details-btn" style="background: none; border: none; color: #3498db; font-size: 11px; cursor: pointer; text-align: left; padding: 0;">View Details</button>
      
      <div id="lg-details-panel" style="display: none; margin-top: 8px; border-top: 1px solid #eee; padding-top: 8px;">
         <div style="font-size: 11px; color: #555;">
           <div>Safe Browsing: ${t.signals.safe_browsing?"❌ Match":"✅ Clean"}</div>
           <div>VirusTotal: ${t.signals.virus_total_malicious} malicious</div>
           <div>SSL: ${t.signals.ssl_secure?"✅ Secure":"⚠️ Insecure"}</div>
         </div>
      </div>
    </div>
  `;const l=i.querySelector("#lg-details-btn"),a=i.querySelector("#lg-details-panel");l&&a&&l.addEventListener("click",()=>{a.style.display="block",i.dataset.expanded="true",l.remove()})}function p(t){i&&(i.innerHTML=`<div style="color: red; font-size: 12px;">Error: ${t}</div>`)}function c(){i&&(i.remove(),i=null,r=null)}
